What is it?
===========

This is the installer for LFS

LFS is an online shop based on Python, Django and jQuery.

How to use it?
==============

Please see 

http://packages.python.org/django-lfs/introduction/installation.html

for more information.

More Information
================

* `Official page <http://www.getlfs.com/>`_
* `Documentation on PyPI <http://packages.python.org/django-lfs/index.html>`_
* `Releases on PyPI <http://pypi.python.org/pypi/django-lfs>`_
* `Source code on bitbucket.org <http://bitbucket.org/diefenbach/django-lfs>`_
* `Google Group <http://groups.google.com/group/django-lfs>`_
* `lfsproject on Twitter <http://twitter.com/lfsproject>`_
* `IRC <irc://irc.freenode.net/django-lfs>`_